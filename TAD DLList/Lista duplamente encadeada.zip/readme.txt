feito na IDE dev C++
windows